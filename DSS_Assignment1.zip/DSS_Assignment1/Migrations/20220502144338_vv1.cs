﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DSS_Assignment1.Migrations
{
    public partial class vv1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
