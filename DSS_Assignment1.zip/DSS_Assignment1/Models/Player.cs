﻿
using System;
namespace DSS_Assignment1.Models;

public class Player
{
	public int PlayerId { get; set; }
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public int PlayerNumber { get; set; }
	public Team Teams { get; set; }
}
