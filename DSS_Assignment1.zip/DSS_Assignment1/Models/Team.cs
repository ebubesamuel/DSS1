﻿
using System;
namespace DSS_Assignment1.Models
{
    public class Team
    {
        public int TeamId { get; set; }
        public string Name { get; set; }
        public int YearCreated { get; set; }
        public ICollection<Player> Players { get; set; }
        public ICollection<League> Leagues { get; set; }
    }
}