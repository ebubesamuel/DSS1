﻿using System;
using DSS_Assignment1.Models;
using Microsoft.EntityFrameworkCore;

namespace DSS_Assignment1.Models
{
    public class FIFA : DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<League> Leagues { get; set; }

        /*
        public FIFA()
        {

        }

        public FIFA(DbContextOptions options) : base(options)
        {

        }

        */
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(@"Server = localhost, 1433; Database = FIFA_DB; User = sa; Password = myPassw0rd");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //TEAM
            modelBuilder.Entity<Team>().Property(a => a.Name).HasMaxLength(150).IsRequired();
            modelBuilder.Entity<Team>().Property(a => a.YearCreated).HasMaxLength(150);

            //LEAGUE
            modelBuilder.Entity<League>().Property(a => a.Name).HasMaxLength(150);
            modelBuilder.Entity<League>().Property(a => a.CupTitle).HasMaxLength(150);

            //PLAYER
            modelBuilder.Entity<Player>().Property(a => a.FirstName).HasMaxLength(150);
            modelBuilder.Entity<Player>().Property(a => a.LastName).HasMaxLength(150);
            modelBuilder.Entity<Player>().Property(a => a.PlayerNumber).HasMaxLength(150);

        }
    }
}