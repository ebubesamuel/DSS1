﻿using System;
namespace DSS_Assignment1.Models
{
    public class League
    {
        public int LeagueId { get; set; }
        public string Name { get; set; }
        public string CupTitle { get; set; }
        public ICollection<Team> Teams { get; set; }
    }
}
